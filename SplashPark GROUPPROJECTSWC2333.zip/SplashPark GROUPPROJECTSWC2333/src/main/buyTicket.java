package main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.Toolkit;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JRadioButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class buyTicket extends JFrame {

	static DecimalFormat priceformatter = new DecimalFormat("#0.00");
	DecimalFormat discountnumber = new DecimalFormat("#0");

	private JPanel contentPane;
	public JLabel lblNewLabel_2;

	static double listpricecust = 0;
	static double finalprice = 0;
	static private JLabel totalTitle;
	static private JLabel totaldisplay;
	static Payment paymentwindow = null;
     
	static boolean splashmember = false;
	/**
	 * Create the frame.
	 * 
	 * @throws IOException
	 */
	static public void calctotalprice(double totalAll) {
		totaldisplay.setText("RM " + priceformatter.format(totalAll));
		listpricecust = totalAll;
		if(splashmember == true) {
			totalAll = totalAll - (totalAll*Main.getdiscountvalue());
		}
		totaldisplay.setText("RM " + priceformatter.format(totalAll));
		
		
		
		finalprice = totalAll;
	}
	
	private boolean containsICNumber(final String icNumber) {
		return Main.getvisitor().stream().filter(cust -> cust.geticNumber().equals(icNumber)).findFirst().isPresent();
	}
	
	static public void setpaymentwindownull() {
		paymentwindow = null;
	}

	public buyTicket(String icNumber) throws IOException {
		tickettypeSelector ticketselector = new tickettypeSelector(icNumber);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent e) {
				ticketselector.dispose();
				Homeframe.getbuttoncreate().setEnabled(true);
			}

			@Override
			public void windowClosing(WindowEvent e) {
				String selectorbutton[] = { "Yes", "No" };
				int PromptResult = JOptionPane.showOptionDialog(null,
						"Are you sure you want to exit?. This ticket will not be saved", "Cancel Ticket ",
						JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, selectorbutton,
						selectorbutton[1]);
				if (PromptResult == JOptionPane.YES_OPTION) {
					Main.getdetails().removeIf(Orders -> Orders.geticNumber().equals(icNumber));
					Main.gettickets().removeIf(Items -> Items.geticNumber().equals(icNumber));
					Main.getvisitor().removeIf(Customer -> Customer.geticNumber().equals(icNumber));
					if(paymentwindow != null) {						
						paymentwindow.dispose();
						paymentwindow = null;
					}
					listpricecust = 0;
					finalprice = 0;
					splashmember = false;
					Homeframe.setticketframenull();
					
					dispose();
					System.out.println("ORDER DELETED");
				}
			}
		});

		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Windows".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		setTitle("SPLASH PARK TICKETING SYSTEM");
		setIconImage(Toolkit.getDefaultToolkit().getImage(buyTicket.class.getResource("/main/logo/logo.png")));
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 1014, 524);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 153, 204));
		contentPane.setBorder(null);
		setContentPane(contentPane);
		setLocationRelativeTo(null);

		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 0, 0));
		panel.setBackground(new Color(0, 51, 204));

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 153, 255));

		JTextField visitornamefield = new JTextField();
		visitornamefield.setBounds(10, 26, 946, 33);
		visitornamefield.setColumns(10);

		JTextField emailfield = new JTextField();
		emailfield.setBounds(10, 83, 176, 27);
		emailfield.setColumns(10);

		JTextArea addressfield = new JTextArea();
		addressfield.setFont(new Font("Tahoma", Font.PLAIN, 11));

		JCheckBox splashmembercheck = new JCheckBox("Yes");
		splashmembercheck.setFont(new Font("Tahoma", Font.PLAIN, 16));
		splashmembercheck.setBounds(558, 236, 59, 32);
		splashmembercheck.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				boolean splashmember = false;
				if (splashmembercheck.isSelected()) {
					splashmember = true;
				}
				else {
					splashmember = false;
				}

				if (splashmember == true) {
					totalTitle.setText("Thank you for being one of our member, You get "
							+ discountnumber.format((Main.getdiscountvalue() * 100)) + "%" + " discount for this purchase!");
					double totalwithdiscount = listpricecust - (listpricecust * Main.getdiscountvalue());
					totaldisplay.setText("RM " + priceformatter.format(totalwithdiscount));
					finalprice = totalwithdiscount;
				} else {
					totalTitle.setText("Total Price");
					totaldisplay.setText("RM " + priceformatter.format(listpricecust));
					finalprice = listpricecust;
				}
			}
		});

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 130, 946, 58);

		JRadioButton malevalueradio = new JRadioButton("Male");
		malevalueradio.setBounds(203, 86, 47, 21);
		JRadioButton femalevalueradio = new JRadioButton("Female");
		femalevalueradio.setBounds(252, 86, 59, 21);
		malevalueradio.setActionCommand("Male");
		femalevalueradio.setActionCommand("Female");

		ButtonGroup genderselector = new ButtonGroup();
		genderselector.add(malevalueradio);
		genderselector.add(femalevalueradio);

		JButton btnNewButton = new JButton("Pay Now");
		btnNewButton.setBounds(787, 349, 169, 35);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String name = visitornamefield.getText();
				String email = emailfield.getText();
				String address = addressfield.getText();
				String gender = "";
				boolean splashmember = false;
				if (splashmembercheck.isSelected()) {
					splashmember = true;
				}

				// ERROR HANDLING FOR RADIO GET ACTION COMMAND
				try {
					gender = genderselector.getSelection().getActionCommand();
				} catch (Exception e1) {
					System.out.println(e1.getMessage());
				}

				// PROCESS STATE
				boolean process = false;

				// ERROR STATE
				boolean visitornameerror = false;
				boolean emailerror = false;
				boolean addresserror = false;
				boolean gendererror = false;
				boolean quantityerror = false;

				// CHECK NAME
				if (name.isEmpty()) {
					visitornameerror = true;
				}

				// CHECK PHONE NO
				if (email.isEmpty()) {
					emailerror = true;
				}

				// CHECK ADDRESS
				if (address.isEmpty()) {
					addresserror = true;
				}

				// CHECK GENDER
				if (gender.isEmpty()) {
					gendererror = true;
				}

				// CHECK IF ITEM ADDED
				int quantitycount = 0;
				for (int i = 0; i < Main.gettickets().size(); i++) {
					if (String.valueOf(Main.gettickets().get(i).geticNumber()).equals(icNumber)) {
						quantitycount = quantitycount + Main.gettickets().get(i).getquantity();
					}
				}

				// CHECK QUANTITY ITEMS ADDED
				if (quantitycount == 0) {
					quantityerror = true;
				}

				// ERROR MESSAGE
				if (visitornameerror || emailerror || addresserror || gendererror || quantityerror) {
					String error = "Check your required field:";
					if (visitornameerror) {
						error += "\nYou have not entered your name";
					}
					if (emailerror) {
						error += "\nYou have not entered your email address";
					}
					if (addresserror) {
						error += "\nYou have not entered your address";
					}
					if (gendererror) {
						error += "\nYou have not tick your gender";
					}
					if (quantityerror) {
						error += "\nYou have not pick your ticket";
					}
					JOptionPane.showMessageDialog(null, error, "Error", JOptionPane.ERROR_MESSAGE);
				} else {
					process = true;
				}

				// IF TRUE, SAVE THE RECORD
				if (process == true) {
					boolean duplicateorderid = containsICNumber(icNumber);
					if (duplicateorderid) {
					} else {						
						Main.getvisitor().add(new visitorClass(icNumber, name, email, address, gender, splashmember));
					}
					if(paymentwindow == null) {						
						paymentwindow = new Payment(icNumber, finalprice);
						paymentwindow.setVisible(true);
					}else {
						paymentwindow.setVisible(true);
					}
				}
			}
		});

		JButton btnNewButton_1 = new JButton("Pick Your Ticket");
		btnNewButton_1.setBounds(114, 230, 128, 38);
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				ticketselector.setVisible(true);
			}
		});

		totalTitle = new JLabel("Total:");
		totalTitle.setBounds(10, 336, 718, 21);
		totalTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
		totalTitle.setForeground(Color.BLACK);

		totaldisplay = new JLabel("-");
		totaldisplay.setBounds(10, 353, 255, 25);
		totaldisplay.setFont(new Font("SansSerif", Font.BOLD, 19));
		
				JLabel lblNewLabel = new JLabel("Address");
				lblNewLabel.setBounds(10, 113, 84, 17);
				lblNewLabel.setFont(new Font("Copperplate Gothic Bold", Font.PLAIN, 14));
		
				JLabel lblNewLabel_6 = new JLabel("Gender");
				lblNewLabel_6.setBounds(226, 69, 62, 17);
				lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		
				JLabel lblNewLabel_4 = new JLabel("Ticket Type");
				lblNewLabel_4.setBounds(115, 198, 139, 44);
				lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		
				JLabel lblNewLabel_5 = new JLabel("SPLASHEESH MEMBERSHIP");
				lblNewLabel_5.setBounds(472, 213, 238, 17);
				lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		
				JLabel lblNewLabel_1 = new JLabel("Visitor Name");
				lblNewLabel_1.setBounds(10, 10, 125, 17);
				lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		
				JLabel lblNewLabel_3 = new JLabel("Email Adress");
				lblNewLabel_3.setBounds(10, 69, 118, 17);
				lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));

		scrollPane.setViewportView(addressfield);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addComponent(panel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE)
				.addComponent(panel_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE)
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 501, GroupLayout.PREFERRED_SIZE))
		);
		panel_1.setLayout(null);
		panel_1.add(lblNewLabel_5);
		panel_1.add(lblNewLabel_1);
		panel_1.add(lblNewLabel_3);
		panel_1.add(visitornamefield);
		panel_1.add(malevalueradio);
		panel_1.add(totaldisplay);
		panel_1.add(totalTitle);
		panel_1.add(femalevalueradio);
		panel_1.add(scrollPane);
		panel_1.add(emailfield);
		panel_1.add(btnNewButton_1);
		panel_1.add(splashmembercheck);
		panel_1.add(lblNewLabel);
		panel_1.add(btnNewButton);
		panel_1.add(lblNewLabel_4);
		panel_1.add(lblNewLabel_6);

		lblNewLabel_2 = new JLabel("Visitor Personal Info");
		lblNewLabel_2.setBackground(new Color(255, 255, 204));
		lblNewLabel_2.setForeground(new Color(255, 255, 204));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 22));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(330)
					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 294, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(376, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addContainerGap(30, Short.MAX_VALUE)
					.addComponent(lblNewLabel_2)
					.addGap(24))
		);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
	}
}
