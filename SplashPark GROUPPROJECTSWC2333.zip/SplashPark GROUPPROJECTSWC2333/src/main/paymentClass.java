package main;

public class paymentClass extends detailClass{
	private String typePay;  //use debit or credit
	private double totalAll; //total price for all tickets
	private double visitorPay;  //how much visitor pay
	
	//normal constructor
	public paymentClass(String icNumber, String typePay, double totalAll, double visitorPay) 
	{
		this.icNumber = icNumber;
		this.typePay = typePay;
		this.totalAll = totalAll;
		this.visitorPay = visitorPay;
	}
	
	//accessor
	public String geticNumber() 
	{
		return icNumber;
	}
	
	public String gettypePay() 
	{
		return typePay;
	}
	
	public double gettotalAll() 
	{
		return totalAll;
	}
	
	public double getvisitorPay() 
	{
		return visitorPay;
	}
}
