package main;

public class ticketClass extends detailClass{
	private int listNo; //number in the list in the table
    private String ticketType; //adult,child,oku
    private int quantity; //ticket quantity
    private double totalTickets;
    
    //default constructor
    public ticketClass()
    {
    	icNumber = null;
    	listNo = 0;
    	ticketType = null;
        quantity = 0;
        totalTickets = 0;
    }
    
    //normal constructor
    public ticketClass(String icNumber, int listNo, String ticketType, int quantity, double totalTickets)
    {
        this.icNumber = icNumber;
        this.ticketType = ticketType;
        this.quantity = quantity;
        this.listNo = listNo;
        this.totalTickets = totalTickets;
    }
    
    //accessor
    public int getlistNo() 
    {
    	return listNo;
    }
    
    public String getticketType()
    {
        return ticketType;
    }
    
    public int getquantity()
    {
        return quantity;
    }
    
    public String geticNumber()
    {
        return icNumber;
    }
    
    public double gettotalTickets()
    {
    	return totalTickets;
    }
}
