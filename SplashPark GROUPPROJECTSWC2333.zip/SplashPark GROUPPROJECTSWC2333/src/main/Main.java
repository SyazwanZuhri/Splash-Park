package main;

import java.util.ArrayList;
import java.awt.Color;

public class Main {
	static ArrayList<visitorClass> visitors = new ArrayList<visitorClass>();
	static ArrayList<ticketClass> ticketlist = new ArrayList<ticketClass>();
	static ArrayList<detailClass> detaillist = new ArrayList<detailClass>();
	static ArrayList<paymentClass> paymentlist = new ArrayList<paymentClass>();
	
	//CONFIGURATION
	static private double discount = 0.35;
	static public double getdiscountvalue() {
		return discount;
	}

	public static ArrayList<visitorClass> getvisitor() {
		return visitors;
	}

	public static ArrayList<ticketClass> gettickets() {
		return ticketlist;
	}
	
	public static ArrayList<detailClass> getdetails() {
		return detaillist;
	}
	
	public static ArrayList<paymentClass> getPayment(){
		return paymentlist;
	}

	public static void main(String[] args) {
		Welcomeframe welcomeframe;
		Homeframe home;

		try {
			welcomeframe = new Welcomeframe();
			welcomeframe.getContentPane().setBackground(new Color(14, 0, 141));
			welcomeframe.getContentPane().setForeground(new Color(14, 0, 141));
			home = new Homeframe();

			welcomeframe.setVisible(true);
			Thread.sleep(2000);
			welcomeframe.progressBar.setVisible(true);
			try {
				for (int i = 0; i <= 100; i += 4) {
					Thread.sleep(20);
					welcomeframe.progressBar.setValue(i);
				}
				Thread.sleep(1000);
				welcomeframe.setVisible(false);
				home.setVisible(true);
			} catch (Exception e) {
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
