package main;

public class detailClass {
	//LINKED BY IC NUMBER
    protected String icNumber;
    private String ticketDate;
    private String ticketTime;
    
    public detailClass() {
    	icNumber = null;
    	ticketDate = null;
    	ticketTime = null;
    }
    
    public detailClass(String icNumber, String ticketDate, String ticketTime) {
    	this.icNumber = icNumber;
    	this.ticketDate = ticketDate;
    	this.ticketTime = ticketTime;
    }
    
    public void setnewicNumber(String icNumber) {
    	this.icNumber = icNumber;
    }
    
    public void setticketDate(String ticketDate) {
    	this.ticketDate = ticketDate;
    }
    
    public void setticketTime(String time) {
    	this.ticketTime = ticketTime;
    }
    
    public String geticNumber() {
    	return icNumber;
    }
    
    public String getticketDate() {
    	return ticketDate;
    }
    
    public String getticketTime() {
    	return ticketTime;
    }
}
