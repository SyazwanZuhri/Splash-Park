package main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.Cursor;
import java.awt.Desktop;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Homeframe extends JFrame {

	SimpleDateFormat newdateformat = new SimpleDateFormat("dd-MM-yyyy");
	SimpleDateFormat newtimeformat = new SimpleDateFormat("hh:mm a");

	private JPanel contentPane;
	private JTable visitorlist;
	static DefaultTableModel listticketmodel;
	private static JButton btnNewButton;
	static buyTicket ticketframe = null;

	static DecimalFormat priceformatter = new DecimalFormat("#0.00");
	static private String icNumbermain = null;
    
	public static void setticketframenull() {
		ticketframe = null;
	}

	public static void showdata() {
		listticketmodel.setRowCount(0);
		for (int i = 0; i < Main.getvisitor().size(); i++) {
			// to calculate all tickets selected price
			double vistlistprice = 0;
			for (int k = 0; k < Main.gettickets().size(); k++) {
				if (String.valueOf(Main.gettickets().get(k).geticNumber())
						.equals(Main.getvisitor().get(i).geticNumber())) {
					vistlistprice = vistlistprice + Main.gettickets().get(k).gettotalTickets();
				}
			}
			if (Main.getvisitor().get(i).getsplashmember() == true) {
				vistlistprice = vistlistprice - (vistlistprice * Main.getdiscountvalue());
			}
			listticketmodel
					.addRow(new Object[] { Main.getvisitor().get(i).getname(), Main.getvisitor().get(i).getemail(),
							Main.getvisitor().get(i).geticNumber(), "RM " + priceformatter.format(vistlistprice) });

		}
	}
	
	static public buyTicket getticketframe() {
		return ticketframe;
	}
	
	static public JButton getbuttoncreate() {
		return btnNewButton;
	}

	private boolean containsICNumber(final String icNumber) {
		return Main.gettickets().stream().filter(order -> order.geticNumber().equals(icNumber)).findFirst().isPresent();
	}

	public void displaydata() {
		Iterator itrcustomer = Main.getvisitor().iterator();
		while (itrcustomer.hasNext()) {
			String customerdatalist = (String) itrcustomer.next();
			System.out.println(customerdatalist);
		}
	}

	public Homeframe() throws IOException {
		setBackground(Color.WHITE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				String selectorbutton[] = { "Yes", "No" };
				int PromptResult = JOptionPane.showOptionDialog(null,
						"Confirm exit?", "Sad to see you go :( " ,
						JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, selectorbutton,
						selectorbutton[1]);
				if (PromptResult == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		displaydata();
		setTitle ("SPLASH PARK TICKETING SYSTEM");
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Windows".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 993, 499);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.GRAY);
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("Ticket");
		mnNewMenu.setFont(new Font("Tahoma", Font.PLAIN, 13));
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem = new JMenuItem("Payment Receipt");
		mntmNewMenuItem.setIcon(new ImageIcon(Homeframe.class.getResource("/main/logo/receipt.png")));
		mntmNewMenuItem.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				//show receipt from older transact
				String icNumber = JOptionPane.showInputDialog(null, "Enter IC Number",
						"Splash Park Receipt", JOptionPane.INFORMATION_MESSAGE);
				if (!(icNumber == null)) {
					if (!icNumber.isEmpty()) {
						boolean duplicateicNumber = containsICNumber(icNumber);
						if (duplicateicNumber) {
							paymentReceipt receiptframe = new paymentReceipt(icNumber);
							receiptframe.setVisible(true);
						} else {
							JOptionPane.showMessageDialog(null,
									"The IC Number you entered not found. Please refer the list", "IC Number has not registered yet",
									JOptionPane.ERROR_MESSAGE);
						}
					} else {
						JOptionPane.showMessageDialog(null, "You have not entered your IC number", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem);

		JMenu mnNewMenu_1 = new JMenu("More");
		mnNewMenu_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		menuBar.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("User Manual");
		mntmNewMenuItem_1.setIcon(new ImageIcon(Homeframe.class.getResource("/main/logo/usermanual.jpg")));
		mntmNewMenuItem_1.setBackground(new Color(250, 240, 230));
		mntmNewMenuItem_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (Desktop.isDesktopSupported()) {
					try {
						File usermanual = new File("usermanual.pdf");
						Desktop.getDesktop().open(usermanual);
					} catch (IOException ex) {
						JOptionPane.showMessageDialog(null, "No app found to open the user manual", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_1);

		JMenuItem mntmNewMenuItem_2 = new JMenuItem("About us");
		mntmNewMenuItem_2.setIcon(new ImageIcon(Homeframe.class.getResource("/main/logo/aboutus.png")));
		mntmNewMenuItem_2.setBackground(new Color(250, 240, 230));
		mntmNewMenuItem_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (Desktop.isDesktopSupported()) {
					try {
						File aboutus = new File("aboutus.pdf");
						Desktop.getDesktop().open(aboutus);
					} catch (IOException ex) {
						JOptionPane.showMessageDialog(null, "No app found to open about us", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_2);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(22, 160, 221));
		contentPane.setBackground(new Color(0, 153, 255));
		contentPane.setBorder(null);
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 296, 870, 82);
		scrollPane.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(35, 38, 183, 0);
		lblNewLabel.setIcon(new ImageIcon(Homeframe.class.getResource("")));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 24));

		btnNewButton = new JButton("GET TICKET");
		btnNewButton.setBounds(383, 384, 186, 51);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setFocusable(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(btnNewButton.isEnabled()) {
					String icNumber = JOptionPane.showInputDialog(null, "To book a ticket, register using IC Number",
							"Enter IC Number", JOptionPane.INFORMATION_MESSAGE);
					icNumbermain = icNumber;
					try {
						ticketframe = new buyTicket(icNumbermain);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					if (!(icNumber == null)) {
						if (!icNumber.isEmpty()) {
							boolean duplicateicNumber = containsICNumber(icNumber);
							if (duplicateicNumber) {
								JOptionPane.showMessageDialog(null,
										"The IC Number you entered already exist. Please enter different IC", "IC is already registered",
										JOptionPane.ERROR_MESSAGE);
							} else {
								System.out.println("NEW OBJECT CREATED");
								Date date = new Date();
								
								Main.getdetails().add(
										new detailClass(icNumber, newdateformat.format(date), newtimeformat.format(date)));
								ticketframe.setVisible(true);
								btnNewButton.setEnabled(false);
							}
						} else {
							JOptionPane.showMessageDialog(null, "Please enter IC Number", "Empty IC Number field",
									JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
		});
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_1 = new JLabel("LIST OF SPLASH PARK VISITORS");
		lblNewLabel_1.setBounds(367, 262, 214, 28);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_2 = new JLabel("OUR ATTRACTIONS");
		lblNewLabel_2.setBounds(349, 125, 266, 32);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 26));
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setBounds(35, 28, 200, 174);
		lblNewLabel_3.setIcon(new ImageIcon(Homeframe.class.getResource("/main/logo/superhurricane.jpg")));
		
		JLabel lblNewLabel_4 = new JLabel("Super Hurricane");
		lblNewLabel_4.setBounds(84, 212, 118, 17);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(760, 38, 90, 119);
		lblNewLabel_5.setIcon(new ImageIcon(Homeframe.class.getResource("/main/logo/monsoonbuster.jpg")));
		
		JLabel lblNewLabel_6 = new JLabel("Monsoon Buster");
		lblNewLabel_6.setBounds(746, 149, 115, 17);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setBounds(427, 10, 90, 97);
		lblNewLabel_7.setIcon(new ImageIcon(Homeframe.class.getResource("/main/logo/piratecove.jpg")));

		visitorlist = new JTable();
		scrollPane.setViewportView(visitorlist);
		listticketmodel = new DefaultTableModel(new Object[][] {},
				new String[] { "Name", "Email", "IC Number", "Price" }) {
			/**
				 * 
				 */
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return false;
			}
		};
		visitorlist.setModel(listticketmodel);
		visitorlist.getColumnModel().getColumn(0).setPreferredWidth(195);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel_1);
		contentPane.add(btnNewButton);
		contentPane.add(lblNewLabel_2);
		contentPane.add(lblNewLabel_4);
		contentPane.add(lblNewLabel_6);
		contentPane.add(lblNewLabel_3);
		contentPane.add(scrollPane);
		contentPane.add(lblNewLabel);
		contentPane.add(lblNewLabel_5);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Pirate Cove");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_8.setBounds(437, 107, 79, 13);
		contentPane.add(lblNewLabel_8);
		setLocationRelativeTo(null);
		setIconImage(new ImageIcon(this.getClass().getResource("/main/logo/logo.png")).getImage());
	}
}
