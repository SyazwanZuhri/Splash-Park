package main;

public class visitorClass extends detailClass{
	//visitor data
    private String name;
    private String email;
    private String address;
    private String gender;
    private boolean splashmember; //visitor get discount if this is true
    
    //default constructor
    public visitorClass(){
    	icNumber = null;
        name = null;
        email = null;
        address = null;
        gender = null;
        splashmember = false;
    }
    
    //normal constructor
    public visitorClass(String icNumber, String name, String email, String address, String gender, boolean splashmember){
        this.icNumber = icNumber;
        this.name = name;
        this.email = email;
        this.address = address;
        this.gender = gender;
        this.splashmember = splashmember;
    }
    
    //accessor
    public String getname(){
        return name;
    }
    
    public String getemail(){
        return email;
    }
    
    public String getaddress(){
        return address;
    }
    
    public boolean getsplashmember(){
        return splashmember;
    }
    
    public String getgender() {
    	return gender;
    }
    
    public String geticNumber(){
        return icNumber;
    }
}
